"use client";
import React, { useEffect, useState } from 'react';

interface Course {
  course: string;
  teacher: string;
  teacherId: string;
}

interface AttendanceRecord {
  date: string;
  time: string;
  status: string;
  course: string;
  room: string;
}

interface AttendanceStats {
  totalClasses: number;
  presents: number;
  absents: number;
  leaves: number;
  percentage: number;
}

export default function Attendance() {
  const [courses, setCourses] = useState<Course[]>([]);
  const [selectedCourse, setSelectedCourse] = useState("");
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  const [stats, setStats] = useState<AttendanceStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [profile, setProfile] = useState<{ className: string; rollNo: string } | null>(null);

  useEffect(() => {
    const getLocalStorageData = () => {
      try {
        const className = localStorage.getItem("className");
        const rollNo = localStorage.getItem("rollNo");
        
        if (!className || !rollNo) {
          setError("Please complete your profile first");
          return;
        }

        setProfile({ className, rollNo });
      } catch (error) {
        setError("Error accessing browser storage");
      }
    };

    getLocalStorageData();
  }, []);

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        if (!profile) return;
        
        const response = await fetch("/api/Component/S/Courses", {
          headers: { 
            className: profile.className 
          }
        });
        
        const data = await response.json();
        setCourses(data);
      } catch (err: any) {
        setError(err.message);
      }
    };

    if (profile) fetchCourses();
  }, [profile]);

  useEffect(() => {
    const fetchAttendance = async () => {
      try {
        if (!selectedCourse || !profile) return;
        
        setLoading(true);
        const response = await fetch(
          `/api/Component/S/Attendance?className=${encodeURIComponent(profile.className)}&rollNo=${profile.rollNo}&course=${encodeURIComponent(selectedCourse)}`
        );

        const { stats, records } = await response.json();
        setStats(stats);
        setAttendance(records);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchAttendance();
  }, [selectedCourse, profile]);

  if (!profile) {
    return <div className="text-red-500 text-center p-8">Please complete your profile first</div>;
  }

  return (
    // ... (keep existing JSX structure unchanged)
  );
}