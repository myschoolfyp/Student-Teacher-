"use client";

import React from "react";
import { useEffect, useState } from "react";

interface Course {
  course: string;
  teacher: string;
  teacherId: string;
}

export default function Courses() {
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    // Client-side only code
    const classLevel = localStorage.getItem("classLevel");
    const classType = localStorage.getItem("classType");
    const className = localStorage.getItem("className");

    const fetchCourses = async () => {
      try {
        if (!classLevel || !classType) {
          throw new Error("Class information not found");
        }

        const response = await fetch("/api/Component/S/Courses", {
          headers: {
            classLevel,
            classType
          }
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.error || "Failed to fetch courses");
        }

        const data = await response.json();
        setCourses(data);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchCourses();
  }, []);

  if (loading) return <div className="text-center p-8 text-xl text-[#0F6466]">Loading courses...</div>;
  if (error) return <div className="text-red-500 text-center p-8">{error}</div>;

  return (
    <div className="min-h-screen p-8 bg-gradient-to-br from-[#f0fdfa] to-[#e0f8f5]">
      <h1 className="text-3xl font-bold text-[#0F6466] mb-8 text-center">
        Enrolled Courses
      </h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {courses.map((course, index) => (
          <div 
            key={index}
            className="p-6 rounded-xl shadow-lg transition-all hover:shadow-xl
                      bg-gradient-to-br from-[#0F6466] to-[#2D9F9C] text-white
                      transform hover:scale-105"
          >
            <h2 className="text-xl font-bold mb-2">{course.course}</h2>
            <p className="text-sm opacity-90">
              Taught by: {course.teacher}
            </p>
          </div>
        ))}
      </div>
      
      {courses.length === 0 && !loading && (
        <p className="text-center text-gray-600 mt-8">No courses found</p>
      )}
    </div>
  );
}