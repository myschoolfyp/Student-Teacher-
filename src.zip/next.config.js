module.exports = {
  api: {
    bodyParser: false,
    externalResolver: true,
  },
}